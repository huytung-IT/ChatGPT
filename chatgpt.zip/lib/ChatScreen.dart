import 'package:chatgpt_app/ChatServices.dart';
import 'package:custom_clippers/custom_clippers.dart';
import 'package:flutter/material.dart';
import 'package:chatgpt_app/SearchHistoryPage.dart';
class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});

  @override
  _ChatScreenState createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  static final TextEditingController _textController = TextEditingController();
  String apiReply = '';
  bool _isSending = false;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
      ChatServices.streamChatConversation.listen((event) {
      if (mounted) {
        setState(() {});
      }
    });
  }
  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Chat GPT'),
          centerTitle: true,
          backgroundColor: const Color.fromRGBO(16, 163, 127, 1),
        ),
        backgroundColor: Colors.white,

        drawer: const Drawer(
          child: SearchHistoryPage(),
        ),
        body: Column(
          children: <Widget>[
            Expanded(
              child: ListView.builder(
                padding: const EdgeInsets.only(
                    left: 20, top: 20, right: 20, bottom: 80),
                itemCount: ChatServices.currentChatConversation == null
                    ? 0
                    : ChatServices.currentChatConversation?.messages.length,
                itemBuilder: (context, index) {
                  var msg =
                  ChatServices.currentChatConversation!.messages[index];
                  if (msg.from == 'gpt') {
                    return Padding(
                      padding: const EdgeInsets.only(right: 200),
                      child: Stack(
                        children: <Widget>[
                          Text(ChatServices.currentChatConversation!
                                      .messages[index].msg,
                          ),
                          // ClipPath(
                          //   clipper: UpperNipMessageClipper(MessageType.receive,
                          //       sizeRatio: 1),
                          //   child: Container(
                          //     padding: const EdgeInsets.all(20),
                          //     decoration: const BoxDecoration(
                          //       color: Colors.white70,
                          //       boxShadow: [
                          //         BoxShadow(
                          //           color: Colors.grey,
                          //           spreadRadius: 2,
                          //           offset: Offset(0, 2),
                          //         ),
                          //       ],
                          //     ),
                          //     child: Text(
                          //       ChatServices.currentChatConversation!
                          //           .messages[index].msg,
                          //       // style: const TextStyle(fontSize: 16,),
                          //     ),
                          //   ),
                          // ),

                          const Positioned(
                            left: 0,
                            top: 0,
                            child: CircleAvatar(
                              backgroundImage: NetworkImage(
                                  'https://th.bing.com/th/id/OIP.JE-inloKPHCLxjm4wtMJigAAAA?pid=ImgDet&rs=1'),
                              radius: 12,
                            ),
                          ),
                          // Positioned(
                          //   right: 0,
                          //   bottom: 0,
                          //   height: 30, // tăng giá trị chiều cao
                          //   width: 96,
                          //   child: GestureDetector(
                          //     onTap: () {
                          //       // Xử lý khi nhấp vào LikeDislikeChatMessage
                          //     },
                          //     child: LikeDislikeChatMessage(
                          //       chatMessage: ChatServices.currentChatConversation!.messages[index],
                          //     ),
                          //   ),
                          // ),
                        ],
                      ),
                    );
                  } else {
                    return Padding(
                      padding: const EdgeInsets.only(
                        left: 280,
                      ),
                      child: Stack(
                        children: [
                          ClipPath(
                            clipper: LowerNipMessageClipper(MessageType.send,
                                sizeRatio: 1),
                            child: Container(
                              padding: const EdgeInsets.all(20),
                              decoration: const BoxDecoration(
                                color: Colors.white70,
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.grey,
                                    spreadRadius: 2,
                                    offset: Offset(0, 2),
                                  ),
                                ],
                              ),
                              child: Text(
                                ChatServices.currentChatConversation
                                    ?.messages[index].msg ??
                                    "",
                                // style: const TextStyle(fontSize: 16),
                              ),
                            ),
                          ),
                          // Positioned(
                          //    right: 75,
                          //    bottom: 0,
                          //    height: 8,
                          //    width: 96,
                          //    child: LikeDislikeChatMessage(
                          //        chatMessage: ChatServices
                          //            .currentChatConversation!
                          //            .messages[index])
                          // ),
                          const Positioned(
                            right: 0,
                            bottom: 0,
                            child: CircleAvatar(
                              backgroundColor: Colors.white,
                              radius: 12,
                              child: Icon(
                                Icons.face_rounded,
                                color: Colors.black,
                              ),
                            ),
                          ),
                        ],
                      ),
                    );
                  }
                },
              ),
            ),
            // if (_isSending) ...[
            //   LoadingAnimationWidget.waveDots(color: Colors.black, size: 10)
            // ],
            // const SizedBox(
            // height: 10
            // ),
            SizedBox(
              height: 50,
              width: 400,
              child: Row(
                children: <Widget>[
                  Expanded(
                    child: TextField(
                      textCapitalization: TextCapitalization.sentences,
                      style: const TextStyle(color: Colors.black),
                      controller: _textController,
                      decoration: const InputDecoration(
                        fillColor: Colors.white70,
                        filled: true,
                        hintText: 'Send a message...',
                      ),
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.send),
                    color: Colors.grey,
                    onPressed: () async {
                      if (_isSending) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                            content: Text(
                                'Bạn không thể gửi nhiều tin cùng một lúc'),
                            backgroundColor: Colors.red,
                          ),
                        );
                        return;
                      }
                      if (_textController.text.isEmpty) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                            content: Text('Vui lòng nhập tin nhắn'),
                            duration: Duration(seconds: 2),
                            backgroundColor: Colors.red,
                          ),
                        );
                        return;
                      }try {
                        _isSending = true;
                        await ChatServices.trySendChatMsg(
                            "from", "to", _textController.text);
                        _textController.clear();
                        setState(() {});
                      } catch (error){
                        ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              content: Text('error'),
                              backgroundColor: Colors.red,
                            ));
                      } finally {
                        setState(() {
                          _isSending = false;
                        });
                      }
                    },
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/*
 */
