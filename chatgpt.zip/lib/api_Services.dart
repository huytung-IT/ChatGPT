import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiServices {

  static Future<dynamic> sendChatRequest(String question) async {
    try {
      var url = Uri.parse('https://api.openai.com/v1/chat/completions');
      var headers = {
        'Content-Type': 'application/json; charset=UTF-8',
        'Authorization': 'Bearer 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'
      };
      var requestBody = {
        "model": "gpt-3.5-turbo",
        "messages": [
          {
            "role": "system",
            "content": "You are a helpful assistant."
          },
          {
            "role": "user",
            "content": question,
          }
        ]
      };
      var response = await http.post(
        url,
        headers: headers,
        body: json.encode(requestBody),
      );

      if (response.statusCode == 200) {
        // var  temp= const Utf8Decoder().convert(response.bodyBytes);
        // temp = json.decode(response.body);
        // print(temp);
        // return  temp;
        return json.decode(response.body);
      }
      else {
        throw Exception('Failed to send question to API: ${response.reasonPhrase}');
      }
    } catch (error) {
      print('Error: $error');
    }
  }


}